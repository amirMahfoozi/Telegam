import java.util.ArrayList;

public class Messenger {
    private static ArrayList<Channel> channels = new ArrayList<>();
    private static ArrayList<Group> groups = new ArrayList<>();
    private static ArrayList<User> users = new ArrayList<>();
    private static User currentUser;

    public static void addGroup(Group group)
    {
        groups.add(group);
    }

    public static void addChannel(Channel channel)
    {
        channels.add(channel);
    }

    public static void addUser(User user)
    {
        users.add(user);
    }

    public static Group getGroupById(String id)
    {
        for (int i = 0; i < groups.size(); i++) {
            if(groups.get(i).getId().equals(id)){
                return groups.get(i);
            }
        }
        return null;
    }

    public static Channel getChannelById(String id)
    {
        for (int i = 0; i < channels.size(); i++) {
            if(channels.get(i).getId().equals(id)){
                return channels.get(i);
            }
        }
        return null;
    }

    public static User getMemberById(String id)
    {
        for (int i = 0; i < users.size(); i++) {
            if(users.get(i).getId().equals(id)){
                return users.get(i);
            }
        }
        return null;
    }

    public static ArrayList<Channel> getChannels() {
        return channels;
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    public static void setCurrentUser(User currentUser) {
        Messenger.currentUser = currentUser;
    }
}
