import java.util.Scanner;
import java.util.regex.Matcher;

public class MessengerMenu {
    private Chat chat;
    private User currentUser;
    private Scanner myScanner;

    public void run(Scanner scanner)
    {
        this.myScanner = scanner;
        currentUser = Messenger.getCurrentUser();
        while (true) {
            String output = "Invalid command!\n";
            String line = scanner.nextLine();
            Matcher matcherCreateChannel = Commands.getMatcher(line,Commands.CREATE_NEW_CHANNEL);
            Matcher matcherShowAllChannels = Commands.getMatcher(line,Commands.SHOW_ALL_CHANNELS);
            Matcher matcherJoinChannel = Commands.getMatcher(line,Commands.JOIN_CHANNEL);
            Matcher matcherShowMyChats = Commands.getMatcher(line,Commands.SHOW_MY_CHATS);
            Matcher matcherCreateNewGroup = Commands.getMatcher(line,Commands.CREATE_GROUP);
            Matcher matcherStartPrivateChat =  Commands.getMatcher(line,Commands.START_PRIVATE_CHAT);
            Matcher matcherLogOut = Commands.getMatcher(line,Commands.LOGOUT);
            Matcher matcherEnterChat = Commands.getMatcher(line,Commands.ENTER_CHAT);
            if (matcherCreateChannel.find())
                output = createChannel(matcherCreateChannel);

            else if (matcherShowAllChannels.find())
                output = showAllChannels();

            else if (matcherJoinChannel.find())
                output = joinChannel(matcherJoinChannel);

            else if (matcherShowMyChats.find())
                output = showChats();

            else if(matcherCreateNewGroup.find())
                output = createGroup(matcherCreateNewGroup);

            else if (matcherStartPrivateChat.find())
                output = createPrivateChat(matcherStartPrivateChat);
            else if(matcherLogOut.find())
                output = "Logged out\n";
            else if(matcherEnterChat.find())
                output = enterChat(matcherEnterChat);
            //TODO REST OF ELSE
            if(!output.equals("dont print"))
                System.out.print(output);
            if(output.equals("Logged out\n"))
            {
                LoginMenu loginMenu = new LoginMenu();
                loginMenu.run(scanner);
            }
        }
    }
    private String showAllChannels()
    {
        String output = "All channels:\n";
        for (int i = 0; i < Messenger.getChannels().size(); i++) {
            output += (i+1)+". "+ Messenger.getChannels().get(i).getName()+", id: "+Messenger.getChannels().get(i).getId()+", members: "+Messenger.getChannels().get(i).getMembers().size()+"\n";
        }
        return output;
    }
    private String showChats()
    {
        String output = "Chats:\n";
        for (int i = currentUser.getChats().size()-1; i >= 0; i--) {
            if(currentUser.getChats().get(i).getClass().getName().toLowerCase().equals("privatechat")) {
                currentUser.getChats().get(i).setCurrentUser(currentUser);
                output += (currentUser.getChats().size()-i)+". "+currentUser.getChats().get(i).getName()+", id: "+currentUser.getChats().get(i).getId() + ", private chat" + "\n";
            }
            else
                output += (currentUser.getChats().size()-i)+". "+currentUser.getChats().get(i).getName()+", id: "+currentUser.getChats().get(i).getId()+", "+currentUser.getChats().get(i).getClass().getName().toLowerCase()+"\n";
        }
        return output;
    }
    private String enterChat(Matcher matcher)
    {
        String chatType = matcher.group(1);
        String id = matcher.group(2);
        if(chatType.equals("group"))
        {
            if(currentUser.getGroupById(id) == null)
                return "You have no "+chatType+" with this id!\n";
            else {
                ChatMenu chatMenu = new ChatMenu();
                chat = currentUser.getGroupById(id);
                System.out.println("You have successfully entered the chat!");
                chatMenu.run(myScanner,chat);
                return "dont print";
            }
        }
        else if(chatType.equals("channel"))
        {
            if(currentUser.getChannelById(id) == null)
                return "You have no "+chatType+" with this id!\n";
            else {
                ChatMenu chatMenu = new ChatMenu();
                chat = currentUser.getChannelById(id);
                System.out.println("You have successfully entered the chat!");
                chatMenu.run(myScanner,chat);
                return "dont print";
            }
        }
        else if(chatType.equals("private chat"))
        {
            if(currentUser.getPrivateChatById(id) == null)
                return "You have no "+chatType+" with this id!\n";
            else {
                ChatMenu chatMenu = new ChatMenu();
                chat = currentUser.getPrivateChatById(id);
                System.out.println("You have successfully entered the chat!");
                chatMenu.run(myScanner,chat);
                return "dont print";
            }
        }
        return "Invalid command!\n";
    }
    private String createChannel(Matcher matcher)
    {
        String id = matcher.group(1);
        String name = matcher.group(2);
        if(!Commands.getMatcher(name,Commands.USERNAME_VALIDATION).matches())
            return "Channel name's format is invalid!\n";
        else{
            for (int i = 0; i < Messenger.getChannels().size(); i++) {
                if(Messenger.getChannels().get(i).getId().equals(id))
                {
                    return "A channel with this id already exists!\n";
                }
            }
        }
        Channel channel = new Channel(currentUser,id,name);
        channel.addMember(currentUser);
        Messenger.addChannel(channel);
        currentUser.addChannel(channel);
        return "Channel "+name+" has been created successfully!\n";
    }
    private String createGroup(Matcher matcher)
    {
        String id = matcher.group(1);
        String name = matcher.group(2);
        if(!Commands.getMatcher(name,Commands.USERNAME_VALIDATION).matches())
            return "Group name's format is invalid!\n";
        else{
            if(Messenger.getGroupById(id) != null)
                return "A group with this id already exists!\n";
        }
        Group group = new Group(currentUser,id,name);
        group.addMember(currentUser);
        Messenger.addGroup(group);
        currentUser.addGroup(group);
        return "Group "+name+" has been created successfully!\n";
    }
    private String createPrivateChat(Matcher matcher)
    {
        String id = matcher.group(1);
        if(Messenger.getMemberById(id) == null)
            return "No user with this id exists!\n";
        else {
            if (currentUser.getPrivateChatById(id) != null)
                return "You already have a private chat with this user!\n";
            else {
                //todo oooooooooooooooooooooooo
                PrivateChat privateChat = new PrivateChat(currentUser, id, Messenger.getMemberById(id).getName());
                privateChat.addMember(currentUser);
                privateChat.addMember(Messenger.getMemberById(id));
                currentUser.addPrivateChat(privateChat);
                if(!currentUser.getId().equals(Messenger.getMemberById(id).getId()))
                    Messenger.getMemberById(id).addPrivateChat(privateChat);
                return "Private chat with "+ Messenger.getMemberById(id).getName() +" has been started successfully!\n";
            }
        }
    }
    private String joinChannel(Matcher matcher)
    {
        String id = matcher.group(1);
        boolean found = false;
        int indexOfChannel = 0;
        for (int i = 0; i < Messenger.getChannels().size(); i++) {
            if(Messenger.getChannels().get(i).getId().equals(id)) {
                found = true;
                indexOfChannel = i;
                for (int j = 0; j < Messenger.getChannels().get(i).getMembers().size(); j++) {
                    if (Messenger.getChannels().get(i).getMembers().get(j).getId().equals(currentUser.getId()))
                        return "You're already a member of this channel!\n";
                }
            }
        }
        if(!found)
            return "No channel with this id exists!\n";

        Messenger.getChannels().get(indexOfChannel).addMember(currentUser);
        currentUser.addChannel(Messenger.getChannels().get(indexOfChannel));
        return "You have successfully joined the channel!\n";
    }
}
