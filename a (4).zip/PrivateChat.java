public class PrivateChat extends Chat{
    private User admin;
    private String id;
    private String name;
    public PrivateChat(User admin, String id, String name) {
        super(admin,id,name);
        this.admin = admin;
        this.name = name;
        this.id = id;
    }

    public User getAdmin() {
        return admin;
    }

    @Override
    public String getName() {
        if (!this.getCurrentUser().getId().equals(admin.getId()))
            return admin.getName();
        return super.getName();
    }

    @Override
    public String getId() {
        if (!this.getCurrentUser().getId().equals(admin.getId()))
            return admin.getId();
        return super.getId();
    }
}
