public class Channel extends Chat{
    public Channel(User admin, String id, String name) {
        super(admin, id, name);
    }
}
