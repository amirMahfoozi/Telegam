import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        LoginMenu loginMenu = new LoginMenu();
        loginMenu.run(scanner);
    }
}
//todo problem is pv with yourself
//todo problem is if a has started pv with b then b dont have a as an already pv member