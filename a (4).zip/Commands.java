import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum Commands {
    REGISTER("^\\s*register\\s+i\\s+(\\S+)\\s+u\\s+(\\S+)\\s+p\\s+(\\S+)$"),
    LOGIN("^\\s*login\\s+i\\s+(\\S+)\\s+p\\s+(\\S+)$"),
    EXIT("^\\s*exit$"),
    USERNAME_VALIDATION("^[A-Za-z0-9_]+$"),
    PASSWORD_VALIDATION("^(?=.*[A-Z])(?=.*[\\*\\.\\!\\@\\$\\%\\^\\&\\(\\)\\{\\}\\[\\]\\:\\;\\<\\>\\,\\?\\/\\~\\_\\+\\-\\=\\|])(?=.*[0-9])(?=.*[a-z]).{8,32}$"),
    CREATE_NEW_CHANNEL("^\\s*create\\s+new\\s+channel\\s+i\\s+(\\S+)\\s+n\\s+(\\S+)$"),
    SHOW_ALL_CHANNELS("^\\s*show\\s+all\\s+channels$"),
    JOIN_CHANNEL("^\\s*join\\s+channel\\s+i\\s+(\\S+)$"),
    SHOW_MY_CHATS("^\\s*show\\s+my\\s+chats$"),
    CREATE_GROUP("^\\s*create\\s+new\\s+group\\s+i\\s+(\\S+)\\s+n\\s+(\\S+)$"),
    START_PRIVATE_CHAT("^\\s*start\\s+a\\s+new\\s+private\\s+chat\\s+with\\s+i\\s+(\\S+)$"),
    LOGOUT("^\\s*logout\\s*$"),
    ENTER_CHAT("^\\s*enter\\s+(.+)\\s+i\\s+(\\S+)$"),
    SEND_MESSAGE("^\\s*send\\s+a\\s+message\\s+c (.+)$"),
    ADD_MEMBER("^\\s*add\\s+member\\s+i\\s+(\\S+)$"),
    SHOW_ALL_MESSAGES("^\\s*show\\s+all\\s+messages$"),
    SHOW_ALL_MEMBERS("^\\s*show\\s+all\\s+members$"),
    BACK("^\\s*back\\s*$");
    private String regex;

    Commands(String regex) {
        this.regex = regex;
    }

    public static Matcher getMatcher(String input, Commands command){
        Pattern pattern = Pattern.compile(command.regex);
        return pattern.matcher(input);
    }
}
