import java.util.HashMap;
import java.util.Scanner;
import java.util.regex.Matcher;

public class LoginMenu {
    public static HashMap<String,User> allUsers = new HashMap<>();
    private String login(Matcher matcher)
    {
        String id = matcher.group(1);
        String password = matcher.group(2);
        if(!allUsers.containsKey(id))
            return "No user with this id exists!";
        else if (!allUsers.get(id).getPassword().equals(password))
            return "Incorrect password!";
        else {
            Messenger.setCurrentUser(allUsers.get(id));
            return "User successfully logged in!";
        }
    }
    private String register(Matcher matcher)
    {
        String id = matcher.group(1);
        String username = matcher.group(2);
        String password = matcher.group(3);
        if (!Commands.getMatcher(username,Commands.USERNAME_VALIDATION).matches())
            return "Username's format is invalid!";
        else if(!Commands.getMatcher(password,Commands.PASSWORD_VALIDATION).matches())
            return "Password is weak!";
        else if(allUsers.containsKey(id))
            return "A user with this ID already exists!";
        else {
            User user = new User(id,username,password);
            allUsers.put(id,user);
            Messenger.addUser(user);
            return "User has been created successfully!";
        }
    }
    public void run(Scanner scanner)
    {
        while (true) {
            String output = "Invalid command!";
            String line = scanner.nextLine();
            Matcher matcherRegister = Commands.getMatcher(line, Commands.REGISTER);
            Matcher matcherLogin = Commands.getMatcher(line, Commands.LOGIN);
            Matcher matcherExit = Commands.getMatcher(line, Commands.EXIT);
            if (matcherRegister.find())
                output = register(matcherRegister);
            else if (matcherLogin.find())
                output = login(matcherLogin);
            else if (matcherExit.find())
                System.exit(0);
            System.out.println(output);
            if(output.equals("User successfully logged in!"))
            {
                MessengerMenu messengerMenu = new MessengerMenu();
                messengerMenu.run(scanner);
            }
        }
    }
}
