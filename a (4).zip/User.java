import java.util.ArrayList;

public class User {
    private ArrayList<Chat> chats = new ArrayList<>();
    private String id;
    private String name;
    private String password;

    public User(String id,String name,String password)
    {
        this.id = id;
        this.name = name;
        this.password = password;
    }

    public void addChat(Chat chat)
    {
        chats.add(chat);
    }

    public void addGroup(Group group)
    {
        addChat((Chat) group);
    }

    public void addChannel(Channel channel)
    {
        addChat((Chat) channel);
    }

    public void addPrivateChat(PrivateChat privateChat)
    {
        addChat((Chat) privateChat);
    }

    public Group getGroupById(String id)
    {
        for (int i = 0; i < chats.size(); i++) {
            if(chats.get(i).getClass().getSimpleName().equals("Group"))
            {
                if(chats.get(i).getId().equals(id))
                {
                    return (Group) chats.get(i);
                }
            }
        }
        return null;
    }

    public Channel getChannelById(String id)
    {
        for (int i = 0; i < chats.size(); i++) {
            if(chats.get(i).getClass().getSimpleName().equals("Channel"))
            {
                if(chats.get(i).getId().equals(id))
                {
                    return (Channel) chats.get(i);
                }
            }
        }
        return null;
    }

    public PrivateChat getPrivateChatById(String id)
    {

        for (int i = 0; i < chats.size(); i++) {
            if(chats.get(i).getClass().getSimpleName().equals("PrivateChat"))
            {
                chats.get(i).setCurrentUser(this);
                if(chats.get(i).getId().equals(id))
                {
                    return (PrivateChat) chats.get(i);
                }
            }
        }
        if(Messenger.getMemberById(id) != null) {
            for (int i = 0; i < Messenger.getMemberById(id).chats.size(); i++) {
                if (Messenger.getMemberById(id).chats.get(i).getClass().getSimpleName().equals("PrivateChat")) {
                    Messenger.getMemberById(id).chats.get(i).setCurrentUser(Messenger.getMemberById(id));
                    if (Messenger.getMemberById(id).chats.get(i).getId().equals(this.getId())) {
                        return (PrivateChat) Messenger.getMemberById(id).chats.get(i);
                    }
                }
            }
        }
        return null;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public ArrayList<Chat> getChats() {
        return chats;
    }

    public String getPassword() {
        return password;
    }
}
