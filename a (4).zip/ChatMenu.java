import java.util.Scanner;
import java.util.regex.Matcher;

public class ChatMenu {
    private Chat chat;
    private User currentUser;

    public void run(Scanner scanner,Chat chat)
    {
        this.chat = chat;
        currentUser = Messenger.getCurrentUser();
        while (true) {
            String output = "Invalid command!\n";
            String line = scanner.nextLine();
            Matcher matcherSendMessage = Commands.getMatcher(line,Commands.SEND_MESSAGE);
            Matcher matcherAddMember = Commands.getMatcher(line,Commands.ADD_MEMBER);
            Matcher matcherShowAllMessages = Commands.getMatcher(line,Commands.SHOW_ALL_MESSAGES);
            Matcher matcherShowAllMembers = Commands.getMatcher(line,Commands.SHOW_ALL_MEMBERS);
            Matcher matcherBack = Commands.getMatcher(line,Commands.BACK);
            if (matcherSendMessage.find())
                output = sendMessage(matcherSendMessage);
            else if(matcherAddMember.find())
                output = addMember(matcherAddMember);
            else if(matcherShowAllMessages.find())
                output = showMessages();
            else if(matcherShowAllMembers.find())
                output = showMembers();
            else if(matcherBack.find())
            {
                MessengerMenu messengerMenu = new MessengerMenu();
                messengerMenu.run(scanner);
            }
            //TODO REST OF ELSE
            System.out.print(output);

        }
    }

    private String showMessages()
    {
        String output = "Messages:\n";
        for (int i = 0; i < chat.getMessages().size(); i++) {
            output += chat.getMessages().get(i).getOwner().getName()+"("+chat.getMessages().get(i).getOwner().getId()+"): \""+chat.getMessages().get(i).getContent()+"\"\n";
        }
        return output;
    }

    private String showMembers()
    {
        if(chat.getClass().getSimpleName().equals("PrivateChat"))
            return "Invalid command!\n";
        String output = "Members:\n";
        for (int i = 0; i < chat.getMembers().size(); i++) {
            if(chat.getOwner().getId().equals(chat.getMembers().get(i).getId()))
                output += "name: "+chat.getMembers().get(i).getName()+", id: "+ chat.getMembers().get(i).getId()+" *owner\n";
            else
                output += "name: "+chat.getMembers().get(i).getName()+", id: "+ chat.getMembers().get(i).getId()+"\n";
        }
        return output;
    }
    private String addMember(Matcher matcher)
    {
        String id = matcher.group(1);
        if(chat.getClass().getSimpleName().equals("PrivateChat"))
            return "Invalid command!\n";
        else {
            if(!chat.getOwner().getId().equals(currentUser.getId()))
                return "You don't have access to add a member!\n";
            else if(Messenger.getMemberById(id) == null)
                return "No user with this id exists!\n";
            else{
                for (int i = 0; i < chat.getMembers().size(); i++) {
                    if(chat.getMembers().get(i).getId().equals(id))
                        return "This user is already in the chat!\n";
                }
                chat.addMember(Messenger.getMemberById(id));
                Messenger.getMemberById(id).addChat(chat);
                if(chat.getClass().getSimpleName().equals("Group"))
                {
                    Message message = new Message(currentUser,Messenger.getMemberById(id).getName()+" has been added to the group!");
                    chat.addMessage(message);
                    Chat chatTemp = chat;
                    for (int i = 0; i < chat.getMembers().size(); i++) {
                        chat.getMembers().get(i).getChats().remove(chat);
                        chatTemp.getMembers().get(i).getChats().add(chatTemp);
                    }
                }
                return "User has been added successfully!\n";
            }
        }
    }
    private String sendMessage(Matcher matcher)
    {
        String messageContent = matcher.group(1);
        if(chat.getClass().getSimpleName().equals("Channel") && !chat.getOwner().getId().equals(currentUser.getId()))
        {
            return "You don't have access to send a message!\n";
        }
        else {
            Message message = new Message(currentUser,messageContent);
            chat.addMessage(message);
            Chat chatTemp = chat;
            for (int i = 0; i < chat.getMembers().size(); i++) {
                chat.getMembers().get(i).getChats().remove(chat);
                chatTemp.getMembers().get(i).getChats().add(chatTemp);
            }
            return "Message has been sent successfully!\n";
        }
    }
}
